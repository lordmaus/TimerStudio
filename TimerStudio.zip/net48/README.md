# ⏱ Timer Studio

**Multi-timer application for Windows — countdown, stopwatch, custom alerts.**

---

## Requirements to Build

| Tool | Where |
|---|---|
| .NET SDK 6 or later | https://dotnet.microsoft.com/download |
| Windows 10 or 11 | — |

> The **output exe** only needs .NET Framework 4.8, which ships with Windows 10/11.
> End users need no extra runtime — just double-click `TimerStudio.exe`.

---

## How to Build

```
cd TimerStudio
build.bat
```

Or: `dotnet build -c Release`

Output: `bin\Release\net48\TimerStudio.exe`
Copy this single exe anywhere and run it.

---

## Features

### Timers
| Feature | Details |
|---|---|
| Multiple timers | Add unlimited timers — all run simultaneously |
| Custom names | Editable inline; name appears in the alert message when it fires |
| Countdown mode | Set hours / minutes / seconds; progress bar drains to zero |
| Stopwatch mode | Counts up with centisecond (1/100s) precision |
| Pause / Resume | Pause any timer and resume exactly where it left off |
| Reset | Return any timer to its configured starting state |

### Alerts
| Feature | Details |
|---|---|
| Alert colors | 8 colors (red, amber, green, blue, lavender, teal, pink, coral) |
| Card flash | Entire timer card changes color when the alert fires |
| Alert sounds | Beep, Chime, Alarm, Bell, Ping, Silent |
| Sound preview | Preview button plays the selected sound before committing |
| Alert repeat | Sound replays up to 4× after firing |
| Named alert | Alert message shows the timer's custom name |
| Dismiss button | One-click dismiss stops the sound and clears the flash |

### Window
| Feature | Details |
|---|---|
| Always on top | ☆ Pin keeps the window above all other windows |
| Hide timers | ⊘ Hide collapses all cards; firing alerts still show a banner |
| Show banner | Firing timer names visible even while timers are hidden |
| Dark / Light theme | ◑ Theme button toggles between dark and light mode |
| System tray | Closing minimizes to tray; double-click to restore |
| Single instance | Second launch shows a friendly message instead of opening twice |
| Tray menu | Restore / Add Timer / Exit from right-click tray icon |

---

## Project Structure

| File | Purpose |
|---|---|
| `App.xaml / .cs` | WPF entry point; theme switching; single-instance mutex |
| `MainWindow.xaml / .cs` | Main window; toolbar; tray icon; global tick |
| `TimerCard.xaml / .cs` | UserControl — one card per timer |
| `TimerModel.cs` | Data model: state machine, timing math, display formatting |
| `AlertSoundPlayer.cs` | Windows Beep API tones — no external audio dependencies |
| `Themes/Dark.xaml` | Dark colour tokens (Catppuccin-inspired) |
| `Themes/Light.xaml` | Light colour tokens |
| `app.manifest` | DPI awareness (PerMonitorV2) + UAC |

---

## Build Output

```
bin\Release\net48\TimerStudio.exe
```

Single exe, no installer needed. Copy anywhere and run.
